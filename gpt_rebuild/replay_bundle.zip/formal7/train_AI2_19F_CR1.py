#!/usr/bin/env python3
"""Deterministic clean-room trainer for AI-2 19-feature replacement CR1."""
import argparse
from pathlib import Path
import numpy as np, pandas as pd, joblib
from sklearn.ensemble import ExtraTreesClassifier
import importlib.util
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('formal7_runtime',HERE/'539_Formal7_Cleanroom_Runtime_v1.py')
rt=importlib.util.module_from_spec(spec); spec.loader.exec_module(rt)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--master',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    df=pd.read_csv(a.master,encoding='utf-8-sig').sort_values('開獎日期').reset_index(drop=True)
    nums=df[[f'號碼{i}' for i in range(1,6)]].astype(int).to_numpy(); Y=rt.make_y(nums)
    dates=pd.to_datetime(df['開獎日期']); start=len(df)-1000
    X=np.vstack([rt.features19(Y,t) for t in range(start,len(df))]); y=Y[start:].reshape(-1)
    model=ExtraTreesClassifier(n_estimators=100,max_depth=4,min_samples_leaf=30,max_features=.8,random_state=539,n_jobs=2)
    model.fit(X,y); Path(a.out).parent.mkdir(parents=True,exist_ok=True); joblib.dump(model,a.out)
    print({'training_target_start':str(dates.iloc[start].date()),'training_target_end':str(dates.iloc[-1].date()),'training_draws':len(X),'candidate_rows':len(y),'features':X.shape[1],'model_out':a.out})
if __name__=='__main__': main()
