#!/usr/bin/env python3
"""Deterministic final-fit trainer for the V1/V2/R3 clean-room 18F artifacts."""
import argparse, joblib, numpy as np, pandas as pd
from pathlib import Path
from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
import importlib.util
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('formal7_runtime',HERE/'539_Formal7_Cleanroom_Runtime_v1.py')
rt=importlib.util.module_from_spec(spec); spec.loader.exec_module(rt)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--master',required=True);ap.add_argument('--outdir',required=True);a=ap.parse_args();out=Path(a.outdir);out.mkdir(parents=True,exist_ok=True)
 df=pd.read_csv(a.master,encoding='utf-8-sig').sort_values('開獎日期').reset_index(drop=True); nums=df[[f'號碼{i}' for i in range(1,6)]].astype(int).to_numpy();Y=rt.make_y(nums)
 start=len(df)-1000;X=np.vstack([rt.features18(Y,t) for t in range(start,len(df))]);y=Y[start:].reshape(-1)
 specs={
  'ET_model.joblib':ExtraTreesClassifier(n_estimators=180,max_depth=5,min_samples_leaf=40,max_features=.8,random_state=539,n_jobs=-1),
  'HGB_model.joblib':HistGradientBoostingClassifier(max_iter=100,max_leaf_nodes=15,learning_rate=.06,l2_regularization=2,min_samples_leaf=80,random_state=539),
  'LOGIT_model.joblib':make_pipeline(StandardScaler(),LogisticRegression(C=.15,max_iter=300))}
 for fn,m in specs.items():m.fit(X,y);joblib.dump(m,out/fn);print(fn,'saved',out/fn)
 print({'training_start':str(pd.to_datetime(df['開獎日期']).iloc[start].date()),'training_end':str(pd.to_datetime(df['開獎日期']).iloc[-1].date()),'draws':len(X),'samples':len(y),'features':X.shape[1]})
if __name__=='__main__':main()
