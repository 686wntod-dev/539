#!/usr/bin/env python3
"""Clean-room, fully specified runnable replacements for the seven 539 formal slots.
These implementations do NOT claim recovery of missing historical production source.
They preserve old IDs as lineage aliases; all replacement model IDs are explicit.
"""
from pathlib import Path
import argparse, hashlib, json
import numpy as np, pandas as pd, joblib
from scipy.special import expit, logit

FEATURES18=['freq3','freq5','freq10','freq20','freq50','freq100','freq200','gap_log','last_draw','neigh1','neigh2','neigh3','neigh4','trend5_20','trend20_100','cooccur1','cooccur2','cooccur3']
FEATURES19=['freq3','freq5','freq10','freq20','freq50','freq100','freq200','gap','last_draw','last3','last5','neigh1','neigh2','neigh3','neigh4','trend5_20','cooccur20','trend20_100','trend10_50']
SEED='539-AI1-TieSeed-20261113-v1|'

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def make_y(nums):
    y=np.zeros((len(nums),39),dtype=np.uint8)
    for i,row in enumerate(nums): y[i,np.asarray(row,dtype=int)-1]=1
    return y

def features18(Y,t):
    H=Y[:t]; X=np.zeros((39,18),dtype=np.float32)
    for j,w in enumerate([3,5,10,20,50,100,200]): X[:,j]=H[-w:].sum(axis=0)/w
    rev=H[::-1]; has=H.any(axis=0); last=np.argmax(rev,axis=0)+1
    X[:,7]=np.log1p(np.where(has,last,t+1)); X[:,8]=Y[t-1]
    recent=H[-20:].sum(axis=0)
    for k in range(1,5):
        vals=np.zeros(39); vals[k:]+=recent[:-k]; vals[:-k]+=recent[k:]
        X[:,8+k]=vals/20
    X[:,13]=X[:,1]-X[:,3]; X[:,14]=X[:,3]-X[:,5]
    co=H[-50:].T@H[-50:]
    for j,lag in enumerate([1,2,3],start=15): X[:,j]=co[:,np.flatnonzero(Y[t-lag])].sum(axis=1)/50
    return X

def features19(Y,t):
    H=Y[:t]; f={}
    for w in [3,5,10,20,50,100,200]: f[f'freq{w}']=H[-w:].sum(axis=0).astype(float)/w
    rev=H[::-1]; has=H.any(axis=0); lastpos=t-1-np.argmax(rev,axis=0)
    last=np.where(has,t-lastpos,t+1).astype(float)
    f['gap']=np.log1p(last); f['last_draw']=Y[t-1].astype(float)
    f['last3']=H[-3:].sum(axis=0).astype(float)/3; f['last5']=H[-5:].sum(axis=0).astype(float)/5
    recent=H[-20:].sum(axis=0).astype(float)
    for k in [1,2,3,4]:
        vals=np.zeros(39); vals[k:]+=recent[:-k]; vals[:-k]+=recent[k:]; f[f'neigh{k}']=vals/20
    f['trend5_20']=f['freq5']-f['freq20']; f['trend20_100']=f['freq20']-f['freq100']; f['trend10_50']=f['freq10']-f['freq50']
    co=H[-20:].T@H[-20:]; prev=np.where(Y[t-1]>0)[0]; f['cooccur20']=co[:,prev].sum(axis=1)/20
    return np.column_stack([f[n] for n in FEATURES19])

def calibrate_sum5(raw):
    z=logit(np.clip(raw,1e-9,1-1e-9)); lo,hi=-20.,20.
    for _ in range(80):
        mid=(lo+hi)/2
        if expit(z+mid).sum()<5: lo=mid
        else: hi=mid
    return expit(z+(lo+hi)/2)

def ai1_scores(Y,t):
    return Y[t-20:t].sum(axis=0).astype(float)
def ai1_order(scores, branch):
    if branch=='Legacy': return sorted(range(39),key=lambda n:(-scores[n],n))
    return sorted(range(39),key=lambda n:(-scores[n],hashlib.sha256((SEED+f'{n+1:02d}').encode()).hexdigest()))

def ai3_scores(Y, dates):
    # Full4036 clean-room conditional transition model; only consecutive draws <=4 days apart.
    counts=np.zeros((39,39),dtype=np.int64); rowcnt=np.zeros(39,dtype=np.int64)
    for t in range(1,len(Y)):
        if (dates.iloc[t]-dates.iloc[t-1]).days > 4: continue
        prev=np.flatnonzero(Y[t-1]); curr=np.flatnonzero(Y[t])
        for i in prev: counts[i,curr]+=1; rowcnt[i]+=1
    prev=np.flatnonzero(Y[-1]); K=2000
    cond=(counts+K*(5/39))/(rowcnt[:,None]+K)
    p=cond[prev].mean(axis=0); p=p*(5/p.sum())
    return p

def pool_record(model_id,score,direction='positive'):
    order=np.argsort(-score,kind='stable') if direction=='positive' else np.argsort(score,kind='stable')
    top=order[:10]+1
    return {'model_id':model_id,'direction':direction,'A':[f'{x:02d}' for x in top[:5]],'B':[f'{x:02d}' for x in top[5:]],'pool':[f'{x:02d}' for x in top],
            'scores':[float(x) for x in score[order]],'ranked_numbers':[f'{x:02d}' for x in order+1]}

def run(master, artifact_dir, outdir):
    master=Path(master); artifact_dir=Path(artifact_dir); outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(master,encoding='utf-8-sig').sort_values('開獎日期').reset_index(drop=True)
    dates=pd.to_datetime(df['開獎日期']); nums=df[[f'號碼{i}' for i in range(1,6)]].astype(int).to_numpy()
    assert len(df)==4036 and dates.is_monotonic_increasing and dates.duplicated().sum()==0
    assert np.all((nums>=1)&(nums<=39)) and all(len(set(r))==5 for r in nums)
    Y=make_y(nums); t=len(df); x18=features18(Y,t); x19=features19(Y,t)
    models={k:joblib.load(artifact_dir/'retrained_18F'/f'{k}_model.joblib') for k in ['ET','HGB','LOGIT']}
    # Strict schema guard: models must accept exactly 18 columns.
    for k,m in models.items(): assert getattr(m,'n_features_in_',18)==18, (k,getattr(m,'n_features_in_',None))
    ai2=joblib.load(artifact_dir/'AI2_BASE_19F_ExtraTrees100_retrained.joblib'); assert ai2.n_features_in_==19
    out={}
    for key,model_id in [('ET','V1-Rebuild-1-CR1'),('HGB','V2-New-1-CR1')]:
        raw=models[key].predict_proba(x18)[:,1]; out[model_id]=pool_record(model_id,raw)
    # R3 reverse: low positive-class probability is excluded; explicitly separate from positive models.
    raw=models['LOGIT'].predict_proba(x18)[:,1]; out['R3-New-1-CR1']=pool_record('R3-New-1-CR1',raw,'reverse')
    # AI-1 deterministic W20 transparent reconstructions.
    s=ai1_scores(Y,t)
    for branch in ['Legacy','TieSeed']:
        order=ai1_order(s,branch); score=np.zeros(39); score[order]=np.linspace(39,1,39)
        out[f'AI-1-{branch}-CR1']=pool_record(f'AI-1-{branch}-CR1',score)
        out[f'AI-1-{branch}-CR1']['tie_break']='number_ascending' if branch=='Legacy' else 'SHA256(seed|NN)_ascending'
        out[f'AI-1-{branch}-CR1']['window']=20; out[f'AI-1-{branch}-CR1']['frequency_counts']={f'{i+1:02d}':int(s[i]) for i in range(39)}
    # AI-2 19-feature ExtraTrees replacement, explicit duplicate last3/freq3 and last5/freq5 columns retained.
    p2=calibrate_sum5(ai2.predict_proba(x19)[:,1]); out['AI-2-19F-CR1']=pool_record('AI-2-19F-CR1',p2)
    out['AI-2-19F-CR1']['probability_sum']=float(p2.sum()); out['AI-2-19F-CR1']['feature_order']=FEATURES19
    # AI-3 full-history transition replacement.
    p3=ai3_scores(Y,dates); out['AI-3-Full4036-CR1']=pool_record('AI-3-Full4036-CR1',p3)
    out['AI-3-Full4036-CR1']['selected_K']=2000
    meta={'status':'CLEANROOM_REPLACEMENT_RUNTIME_PASS_ORIGINAL_PRODUCTION_SOURCE_NOT_CLAIMED',
          'master_rows':len(df),'master_sha256':sha_file(master),'date_start':str(dates.iloc[0].date()),'data_cutoff':str(dates.iloc[-1].date()),
          'models':out,'artifacts':{p.name:sha_file(p) for p in sorted(artifact_dir.glob('*')) if p.is_file()},
          'feature_schemas':{'V1/V2/R3':FEATURES18,'AI2':FEATURES19,'AI1':'20-draw frequency count; deterministic tie-break','AI3':'39x39 one-step transition counts, K=2000'},
          'limitations':['Replacement runtime removes operational missing-code/model/schema blockers.','It does not recover or prove the identity of the historical production source.','No performance superiority or R3 90% precision is claimed.','No new official prediction lock is created by this smoke test.']}
    (outdir/'runtime_smoke_output.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    return meta

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--master',required=True); ap.add_argument('--artifacts',required=True); ap.add_argument('--outdir',required=True)
    a=ap.parse_args(); print(json.dumps(run(a.master,a.artifacts,a.outdir),ensure_ascii=False,indent=2))
