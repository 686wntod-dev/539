import pandas as pd, numpy as np, json, hashlib, os, platform, sys, joblib
from pathlib import Path
from sklearn.ensemble import HistGradientBoostingClassifier
import sklearn
B=Path('/mnt/data/539_雙線攻關_2026-11-15')
MASTER=Path('/mnt/data/539_AI監督_2026-11-15/539_整合標準主檔_4036期_追加2026-11-14_v1.csv')
master=pd.read_csv(MASTER); N=len(master)
D=np.zeros((N,39),dtype=np.int8)
for j in range(1,6): D[np.arange(N),master[f'號碼{j}'].astype(int).to_numpy()-1]=1
cum=np.vstack([np.zeros((1,39),dtype=np.int32),np.cumsum(D,axis=0)])
pair_cum=np.zeros((N+1,39,39),dtype=np.int32)
for i in range(N): pair_cum[i+1]=pair_cum[i]+np.outer(D[i],D[i])
last=np.full(39,-1000,dtype=np.int32); rows=[]; labels=[]; meta=[]
for t in range(200,N+1):
    if t>0: last[np.where(D[t-1]==1)[0]]=t-1
    f=[np.arange(1,40,dtype=np.float32)]
    for w in [5,10,20,50,100,200]: f.append((cum[t]-cum[max(0,t-w)]).astype(np.float32))
    f.append(np.minimum(t-1-last,500).astype(np.float32))
    for w in [1,2,3,5]: f.append((cum[t]-cum[max(0,t-w)]).astype(np.float32))
    for delta in [-2,-1,1,2]:
        src=np.arange(39)+delta; ok=(src>=0)&(src<39)
        for w in [20,50]:
            z=np.zeros(39,dtype=np.float32); z[ok]=(cum[t]-cum[max(0,t-w)])[src[ok]]; f.append(z)
    f10=(cum[t]-cum[max(0,t-10)]).astype(np.float32); f50=(cum[t]-cum[max(0,t-50)]).astype(np.float32)
    f20=(cum[t]-cum[max(0,t-20)]).astype(np.float32); f100=(cum[t]-cum[max(0,t-100)]).astype(np.float32)
    f.extend([f10-f50/5,f20-f100/5,D[t-1].astype(np.float32)])
    for k in [1,2,3]:
        recent=D[max(0,t-k):t].max(axis=0).astype(np.int32)
        for w in [20,50,100]:
            pc=pair_cum[t]-pair_cum[max(0,t-w)]
            f.append((pc@recent).astype(np.float32))
    mat=np.column_stack(f)
    rows.append(mat); labels.append(D[t] if t<N else np.zeros(39,dtype=np.int8)); meta.extend([t+1]*39)
# rows for t=200..N-1 train labels D[t], and final t=N is target 4037 feature only
Xall=np.vstack(rows[:-1]); y=np.concatenate(labels[:-1]); meta=np.asarray(meta[:-39])
Xnext=rows[-1]
train=(meta>=N-999)&(meta<=N)
assert train.sum()==1000*39,(train.sum(),meta.min(),meta.max())
clf=HistGradientBoostingClassifier(max_iter=80,learning_rate=.05,max_leaf_nodes=15,l2_regularization=1.0,random_state=539)
clf.fit(Xall[train],y[train])
probs=clf.predict_proba(Xnext)[:,1]
order=np.argsort(probs,kind='mergesort'); sel=order[:10]
# local timestamp captured immediately before writing immutable prediction
import subprocess
locked_at=subprocess.check_output(['bash','-lc','TZ=Asia/Taipei date -Iseconds']).decode().strip()
master_sha=hashlib.sha256(MASTER.read_bytes()).hexdigest()
code_path=Path(__file__); code_sha=hashlib.sha256(code_path.read_bytes()).hexdigest()
feature_names=['number']+[f'freq_{w}' for w in [5,10,20,50,100,200]]+['omission_capped500']+[f'recent_{w}' for w in [1,2,3,5]]+[f'neighbor_delta_{d}_freq_{w}' for d in [-2,-1,1,2] for w in [20,50]]+['trend_10_vs_50','trend_20_vs_100','last_draw_indicator']+[f'cooccur_last{k}_draws_window{w}' for k in [1,2,3] for w in [20,50,100]]
assert len(feature_names)==Xnext.shape[1],(len(feature_names),Xnext.shape[1])
schema_sha=hashlib.sha256(json.dumps(feature_names,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
params={'max_iter':80,'learning_rate':0.05,'max_leaf_nodes':15,'l2_regularization':1.0,'random_state':539,'training_window_targets':1000,'training_targets':[N-999,N],'feature_count':len(feature_names),'refit_policy':'single final fit on latest 1000 targets for 2026-11-16 prospective shadow'}
params_sha=hashlib.sha256(json.dumps(params,sort_keys=True,separators=(',',':')).encode()).hexdigest()
pred={'model_id':'R3-HGB-NoPP-Shadow-v1','track':'PROSPECTIVE_SHADOW_ONLY','target_date':'2026-11-16','target_index_1based':N+1,'data_cutoff_date':str(master['開獎日期'].iloc[-1]),'data_cutoff_draw_index':N,'master_sha256':master_sha,'code_sha256':code_sha,'feature_schema_sha256':schema_sha,'parameters_sha256':params_sha,'locked_at':locked_at,'direction':'reverse_exclusion','excluded_10':[int(i+1) for i in sel],'A_5':[int(i+1) for i in sel[:5]],'B_5':[int(i+1) for i in sel[5:]],'scores':{f'{i+1:02d}':float(probs[i]) for i in order},'training_window_targets':[N-999,N],'training_samples':int(train.sum()),'feature_count':int(Xnext.shape[1]),'historical_status':'POST_DRAW_EXPLORATORY_NOT_BLIND_TEST','prospective_status':'PENDING_OFFICIAL_RESULT'}
canonical=json.dumps(pred,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode();pred_sha=hashlib.sha256(canonical).hexdigest()
run_id=hashlib.sha256((master_sha+code_sha+params_sha+schema_sha+locked_at).encode()).hexdigest()
lock_id=hashlib.sha256((run_id+pred_sha).encode()).hexdigest()
pred['prediction_sha256']=pred_sha;pred['model_run_id']=run_id;pred['prediction_lock_id']=lock_id
out=B/'R3_HGB_NoPP_2026-11-16_prediction_lock.json';out.write_text(json.dumps(pred,ensure_ascii=False,indent=2))
joblib.dump(clf,B/'R3_HGB_NoPP_2026-11-16_model.joblib')
(B/'R3_HGB_NoPP_2026-11-16_feature_schema.json').write_text(json.dumps({'features':feature_names,'sha256':schema_sha},ensure_ascii=False,indent=2))
print(json.dumps({'locked_at':locked_at,'excluded_10':pred['excluded_10'],'A':pred['A_5'],'B':pred['B_5'],'master_sha':master_sha,'code_sha':code_sha,'schema_sha':schema_sha,'params_sha':params_sha,'prediction_sha':pred_sha,'model_run_id':run_id,'prediction_lock_id':lock_id,'training_samples':int(train.sum()),'features':len(feature_names)},ensure_ascii=False,indent=2))
