import pandas as pd,numpy as np,json,joblib,hashlib
from pathlib import Path
B=Path('/mnt/data/539_雙線攻關_2026-11-15'); master=pd.read_csv('/mnt/data/539_AI監督_2026-11-15/539_整合標準主檔_4036期_追加2026-11-14_v1.csv');N=len(master)
D=np.zeros((N,39),dtype=np.int8)
for j in range(1,6):D[np.arange(N),master[f'號碼{j}'].astype(int).to_numpy()-1]=1
cum=np.vstack([np.zeros((1,39),dtype=np.int32),np.cumsum(D,axis=0)]);pc=np.zeros((N+1,39,39),dtype=np.int32)
for i in range(N):pc[i+1]=pc[i]+np.outer(D[i],D[i])
last=np.full(39,-1000,dtype=np.int32)
for t in range(200,N+1):
 if t>0:last[np.where(D[t-1]==1)[0]]=t-1
# rebuild final target feature vector with only prior data
f=[np.arange(1,40,dtype=np.float32)]
for w in [5,10,20,50,100,200]:f.append((cum[N]-cum[max(0,N-w)]).astype(np.float32))
f.append(np.minimum(N-last,500).astype(np.float32))
for w in [1,2,3,5]:f.append((cum[N]-cum[max(0,N-w)]).astype(np.float32))
for delta in [-2,-1,1,2]:
 src=np.arange(39)+delta;ok=(src>=0)&(src<39)
 for w in [20,50]:
  z=np.zeros(39,dtype=np.float32);z[ok]=(cum[N]-cum[max(0,N-w)])[src[ok]];f.append(z)
f10=(cum[N]-cum[N-10]).astype(np.float32);f50=(cum[N]-cum[N-50]).astype(np.float32);f20=(cum[N]-cum[N-20]).astype(np.float32);f100=(cum[N]-cum[N-100]).astype(np.float32)
f.extend([f10-f50/5,f20-f100/5,D[N-1].astype(np.float32)])
for k in [1,2,3]:
 recent=D[N-k:N].max(axis=0).astype(np.int32)
 for w in [20,50,100]:f.append(((pc[N]-pc[N-w])@recent).astype(np.float32))
X=np.column_stack(f)
model=joblib.load(B/'R3_HGB_NoPP_2026-11-16_model.joblib');p=model.predict_proba(X)[:,1];order=np.argsort(p,kind='mergesort')
lock=json.loads((B/'R3_HGB_NoPP_2026-11-16_prediction_lock.json').read_text());nums=[int(i+1) for i in order[:10]]
assert nums==lock['excluded_10'],(nums,lock['excluded_10'])
assert hashlib.sha256(Path('/mnt/data/539_AI監督_2026-11-15/539_整合標準主檔_4036期_追加2026-11-14_v1.csv').read_bytes()).hexdigest()==lock['master_sha256']
assert len(X[0])==lock['feature_count']
print(json.dumps({'reproduce':'PASS','excluded_10':nums,'prediction_lock_id':lock['prediction_lock_id'],'feature_count':len(X[0]),'master_sha_match':True,'score_max_abs_diff':float(np.max(np.abs(p-np.array([lock['scores'][f'{i+1:02d}'] for i in range(39)]))))},ensure_ascii=False,indent=2))
