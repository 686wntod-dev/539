# GPT Rebuilt 539 Model Package v1

This is a reproducible clean-room / shadow package assembled from retained ChatGPT project artifacts. It is **not** the historical Production source and is **not** Canonical Registry v3. Production authorization is false.

## Reproduced lock evidence
- Formal7 clean-room lock for 2026-11-17: 7/7 A/B/Pool/39-rank exact replay; runtime SHA and all eight model artifact hashes checked.
- Full4034 Shadow lock for 2026-11-16: 4/4 exact rank/A/B/Pool replay.
- R3-HGB-NoPP Shadow lock for 2026-11-16: exact 10-number reverse exclusion and all 39 scores reproduced (max absolute difference 0).
- Combined: 12/12 retained lock replays. These are historical replay checks, not new predictions or evidence of predictive superiority.

## Run
Python environment used for current validation: Python 3.13.5, numpy 2.3.5, pandas 2.2.3, scipy 1.17.0, scikit-learn 1.8.0, joblib 1.5.3.

```bash
pip install numpy==2.3.5 pandas==2.2.3 scipy==1.17.0 scikit-learn==1.8.0 joblib==1.5.3
python validate_rebuild.py
```

## Important boundaries
- AI-1 Legacy and TieSeed are one model family, not independent votes.
- AI-2 19F is a transparent replacement/proxy; F18/F19 provenance limitations remain.
- AI-3 Full4037 is a rebuilt transition model; it is not the old Legacy executable.
- R3-HGB replay here is the 2026-11-16 Shadow challenger lock. It does not recover the missing 2026-11-17 A-line trainer or B-line program/lock.
- The formal7 runtime is a clean-room replacement. It must not be represented as historical Production source.
- The R3 fixed-10 exclusion 90% target is not proven.
- The 4037 master includes a user-confirmed 2026-11-16 draw; period inference remains separately labeled.
- No new prediction lock is created by validation.
- A fresh retraining attempt in the current Python/scikit-learn environment did not reproduce the archived ET/HGB/LOGIT/AI-2 artifact bytes or rankings. Those candidate artifacts were not promoted; only the archived hash-verified artifacts are used for the 12-lock replay. See `training_rebuild_comparison.json`.
