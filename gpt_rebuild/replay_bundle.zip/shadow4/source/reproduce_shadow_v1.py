#!/usr/bin/env python3
"""Reproduce 539 full-history walk-forward Shadow v1 experiment.
Input: 539_整合標準主檔_4034期_v1.csv
Only uses draws strictly before each target draw.
"""
import argparse, hashlib, json
import numpy as np, pandas as pd
from scipy.stats import hypergeom, binom

def z(x):
    sd=x.std()
    return (x-x.mean())/sd if sd>1e-12 else np.zeros_like(x,dtype=float)

def score_at(Y,t,version):
    H=Y[:t]
    f={f"f{w}":H[-w:].sum(axis=0).astype(float) for w in (3,5,10,20)}
    f["full"]=H.sum(axis=0).astype(float)
    f["trend"]=H[-10:].sum(axis=0)/10-(H[-20:-10].sum(axis=0)/10 if t>=20 else H[:max(1,t-10)].sum(axis=0)/max(1,min(10,t-10)))
    recent=H[-20:]; neigh=np.zeros(39)
    for k in (1,2):
        neigh[k:]+=recent[:,:39-k].sum(axis=0)
        neigh[:-k]+=recent[:,k:].sum(axis=0)
    f["neighbor"]=neigh
    gaps=np.empty(39)
    for j in range(39):
        ix=np.flatnonzero(H[:,j]); gaps[j]=min(100,t-1-ix[-1]) if len(ix) else min(100,t)
    f["gap"]=gaps
    if version=="V1":
        w={"f3":.27,"f5":.24,"f10":.20,"f20":.17,"full":.08,"neighbor":.04}
        return sum(a*z(f[k]) for k,a in w.items())
    if version=="V2":
        w={"f3":.18,"f5":.18,"f10":.16,"f20":.14,"full":.08,"gap":.16,"neighbor":.10}
        return sum(a*z(f[k]) for k,a in w.items())
    if version=="R3": return -score_at(Y,t,"V2")
    if version=="EXP_DECAY":
        ages=np.arange(t-1,-1,-1); decay=np.exp(-np.log(2)*ages/8.0)
        exp=(decay[:,None]*H).sum(axis=0)/decay.sum()
        return .78*z(exp)+.14*z(f["neighbor"])-.08*z(f["gap"])
    if version=="TREND":
        return .60*z(f["f10"])+.25*z(f["trend"])+.10*z(f["neighbor"])-.05*z(f["gap"])
    if version=="MIX":
        return .55*z(f["f20"])+.25*z(f["full"])+.15*z(f["trend"])+.05*z(f["neighbor"])
    raise ValueError(version)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("master"); ap.add_argument("--out",default="shadow_out"); args=ap.parse_args()
    df=pd.read_csv(args.master); nums=df[[f"號碼{i}" for i in range(1,6)]].to_numpy(dtype=int)
    dates=pd.to_datetime(df["開獎日期"])
    assert len(df)==4034 and dates.is_monotonic_increasing and dates.duplicated().sum()==0
    assert np.all((nums>=1)&(nums<=39)) and all(len(set(r))==5 for r in nums)
    Y=np.zeros((len(df),39),dtype=np.uint8)
    for i,row in enumerate(nums): Y[i,row-1]=1
    versions=["V1","V2","R3","EXP_DECAY","TREND","MIX"]; start=20
    rows=[]
    for t in range(start,len(df)):
        for v in versions:
            s=score_at(Y,t,v); pool=np.argsort(-s,kind="stable")[:10]+1
            h=int(np.isin(nums[t],pool).sum())
            rows.append({"target_date":str(dates.iloc[t].date()),"target_index":t+1,"model":v,
                         "pool":" ".join(f"{x:02d}" for x in sorted(pool)),"pool_hits":h,
                         "data_cutoff":str(dates.iloc[t-1].date()),"walk_forward":True})
    pd.DataFrame(rows).to_csv(args.out,index=False,encoding="utf-8-sig")
if __name__=="__main__": main()
